package com.example.order_service.dto;


public record OrderItemDto(
  Long id,
  Long productId,
  Integer quantity
) {}
